"""var1=6
var2=56
var3=int(input())
if var3>var2:
  print("Greater")
elif var2==var3:
    print("equal")

else:
    print("Lesser")"""
#list1=[2,5,7]
#if 5 in list1:
 #   print("YES it is in the list")

age=int(input())
if age>18:
    print("you can drive")
elif age==18:
    print("come here to decide")
else:
    print("no you can not drive")