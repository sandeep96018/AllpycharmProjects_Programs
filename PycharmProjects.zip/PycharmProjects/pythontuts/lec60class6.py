class Employee:
    number_of_leaves=8
    def __init__(self,aname,asalary,arole):
        self.name=aname
        self.salary=asalary
        self.role=arole

    def printdetails(self):
        return f"Name is {self.name},salary is {self.salary} and role is {self.role}"

    @classmethod
    def change_leaves(cls,newleaves):
        cls.number_of_leaves=newleaves
    @classmethod
    def dash(cls,string):
        return cls(*string.split("-"))
    @staticmethod
    def printgood(string):
        print("This is good" + string)



harry=Employee("Harry",5000,"Instructor")
rohan=Employee("Rohan",10000,"Student")
karan=Employee.dash("karan-3000-Student")

print(karan.printgood(" Harry"))