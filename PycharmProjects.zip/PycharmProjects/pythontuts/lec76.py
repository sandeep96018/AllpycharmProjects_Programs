khana=["Roti","Daal","Chawal"]
for item in khana:
    if item=="Daal":
        break
else:
    print("Your item is not found")