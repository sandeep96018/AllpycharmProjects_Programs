import json
# data ='{"var1":"harry","var2":56}'
# # print(data)
# parsed=json.loads(data)
# print(parsed['var1'])

data2={
    "channel_name":"CodeWithHaryy",
    "cars_name":["bmw","Audi","ferrari"],
    "fridge":('Roti',540),
    "isbad":False
}
jscomp=json.dumps(data2)
print(jscomp)       