import urllib.request as ur
import json

json_url = input("Enter location: ")
print("Retrieving ", json_url)
data = ur.urlopen(json_url).read().decode('utf-8')
print('Retrieved', len(data), 'characters')
json_obj = json.loads(data)

s = 0
tot = 0

for comment in json_obj["comments"]:
    s =s+ int(comment["count"])
    tot=tot + 1

print('Count:', tot)
print('Sum:', s)