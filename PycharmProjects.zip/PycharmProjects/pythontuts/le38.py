# #lambda function or anonymous funnction
# def add(a,b):
#     return  a+b
add =lambda x,y:x+y
print(add(20,14))