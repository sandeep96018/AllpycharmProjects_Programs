var1="hello sandeep"
var2=44
var3=33.5
var4=" kushwaha"
var5="5"
var6="8"
print(type(var1))
print(var1+var4)
print(int(var5)+int(var6))
print(5*str((int(var5)+int(var6))))
#typcasting
"""str()
int()
float()"""
print("enter first number")
n1=input()
print("enter second number")
n2=input()
print("sum is",int(n1)+int(n2))