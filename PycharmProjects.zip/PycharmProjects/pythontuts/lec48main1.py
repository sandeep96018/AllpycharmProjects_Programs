def printhar(string):
    return f"Ye string {string} ko de do thakur "
def add(num1,num2):
    return num1+num2+5
print("the name is ",__name__)
if __name__ == '__main__':
    print(printhar("Sandeep"))
    o=add(4,6)
    print(o)