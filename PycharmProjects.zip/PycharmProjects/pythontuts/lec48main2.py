import lec48main1
print(lec48main1.add(5,3))