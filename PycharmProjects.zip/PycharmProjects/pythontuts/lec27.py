#file to basics
"""
"r"- open file for reading
"w"-open a file for writting
"x"-create file if not exist
"a"- add more content to a file
"t"-text mode
"b"-binary mode
"+"-read and write mode




"""