class A:
    def det(self):
        print("i m a method from class A")

class B(A):
    def det(self):
        print("i m a method from class B")

class C(A):
    def det(self):
        print("i m a method from class C")

class D(C,B):
    pass

a=A()
b=B()
c=C()
d=D()
d.det()