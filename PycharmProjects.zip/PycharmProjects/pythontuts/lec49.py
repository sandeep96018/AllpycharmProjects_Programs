lis=["Sandeep","Shivam","Sanjay","Kuldeep","Abhishek"]
# for item in lis:
#     print(item,"And",end=" ")
a=" , ".join(lis)
print(a,"are MCa Students")