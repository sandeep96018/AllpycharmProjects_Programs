import random
i=1
we=0
com=0
lst=["snake","water","gun"]
while(i<5):
    ch=random.choice(lst)
    print("enter your choice|| snake or water or gun")
    i=i+1
    a=str(input())
    if (a==ch):
        print("your and computer choice same!",a,"play again")
        continue
    elif (a=="snake"):
        if ch=="water":
            we=we+1
            print("your choice is",a,"computer's choice is",ch)
            print("your points=",we,"computers points=",com)
        else:
            com=com+1
            print("your choice is", a, "computer's choice is", ch)
            print("your points=", we, "computers points=", com)
    elif(a=="water"):
        if ch=="snake":
            com=com+1
            print("your choice is", a, "computer's choice is", ch)
            print("your points=", we, "computers points=", com)
        else:
            we=we+1
            print("your choice is", a, "computer's choice is", ch)
            print("your points=", we, "computers points=", com)
    elif (a=="gun"):
        if ch=="snake":
            we=we+1
            print("your choice is", a, "computer's choice is", ch)
            print("your points=", we, "computers points=", com)
        else:
            com=com+1
            print("your choice is", a, "computer's choice is", ch)
            print("your points=", we, "computers points=", com)
print("Game Over \n")
if(com>we):
    print("winner is computer with points",com,"and your point is",we,"out of 10")
elif(com==we):
    print("equal points", com)
else:
    print("wiiner is you with points",we,"and computer point is",com,"out of 10")

