"""list1=[["harry",1],["sandeep",2],["rohit",3],["shivam",4]]
dict1=dict(list1)
print(dict1)
for item,lolloypop in dict1.items():
    print(item,"eating lollypop is",lolloypop)"""
items=[int,float,"sandeep",2,3,5,55,77,44,32,22,6]
for item in items:
    if str(item).isnumeric() and item>6:
        print(item)