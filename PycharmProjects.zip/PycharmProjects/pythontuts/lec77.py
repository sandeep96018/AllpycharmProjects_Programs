import time
from functools import lru_cache

@lru_cache(3)#picli teeen iteration ko save karta hai agr same n of inputs then no sleep
def somework(n):
    time.sleep(3)
    return n
if __name__ == '__main__':
    print("Now running Some Work")
    somework(3)
    print("Done!calling again")
    somework(3)
    print("Calles again")

