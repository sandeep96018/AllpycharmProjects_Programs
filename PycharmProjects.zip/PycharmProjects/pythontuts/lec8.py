#please dont remove this line
"""multi
line
ignore
now"""
"""multi
line comment"""
print("subscribe my channel","watch my channell",end=" ,")
print("bhai vedio bhi like kr dena")
print("c:\'naryysandeep")