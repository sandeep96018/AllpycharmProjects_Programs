i=0
while(True):

    if i<=5:
        i=i+1
        continue
    print(i, end=" ")
    i=i+1
    if(i==44):
        break
