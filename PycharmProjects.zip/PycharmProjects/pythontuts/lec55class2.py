class Employee:
    number_of_leaves=8
    pass
harry=Employee()
rohan=Employee()

harry.name="Harry"
harry.salary=5000
harry.role="Instructor"

rohan.name="Rohan"
rohan.salary=8000
rohan.role="Student"

print(harry.salary)
print(Employee.number_of_leaves)
print(rohan.__dict__)
Employee.number_of_leaves=12
print(Employee.__dict__)
print(Employee.number_of_leaves)