guse=1
while(True):
    num=20
    print("enter any number")
    unum=int(input())
    if unum==num:
        print("you have entered correct number",unum,"and gueses is",guse)
        break
    elif unum<24 and guse<6:
        if unum<16:
            guse=guse+1
            print("enter the greater number than 16")
        elif unum>19 and unum<21:
            guse=guse+1
            print("enter the number between 16 and 24")
        elif unum>18 and unum<22:
            guse=guse+1
            print("enter the value between 18 and 22")
        elif unum>16 and unum<24:
            guse=guse+1
            print("please enter the number between 16 and 24")
    elif unum>24 and guse<6:
        guse=guse+1
        print("please enter the number less than 24")
    elif guse>5:
            print("Game Over!you have entered maximum numbe of guesus")
            break





