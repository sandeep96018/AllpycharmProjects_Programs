def searcher():
    import time
    # some 4 seconds time consuming task
    book="This is a boo on harry and code with harry and good"
    time.sleep(4)

    while True:
        text=(yield)
        if text in book:
            print("your text is in the book")
        else:
            print("Your text is ot in the book")
search=searcher()
next(search)
search.send("harry")
input("press any key")
search.send("harry and")
search.close()

search.send("harry and")



# input("press any key")
# search.send("harry and maryy")
# input("press any key")
# search.send("harry and youl")

