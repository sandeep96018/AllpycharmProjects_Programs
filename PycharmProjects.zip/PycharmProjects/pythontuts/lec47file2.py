a=7
def printjoke(str):
    print(f"This is a joke{str}")