a=int(input("enter a"))
b=int(input("enter b"))
print(" A b se bda hai bhai") if a>b else print("B A se bda hai bhai")