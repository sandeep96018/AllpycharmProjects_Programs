#iterable __iter__() or__getitem__()
#iterator  __next__()
# iteration

# def gen(n):
#     for i in range(n):
#         yield i
# g=gen(3)
# print(g.__next__())
# print(g.__next__())
# print(g.__next__())
# # print(g.__next__())

h="Harry"
ier=iter(h)
print(ier.__next__())
print(ier.__next__())
print(ier.__next__())
print(ier.__next__())
print(ier.__next__())
print(ier.__next__())


# for c in h:
#     print(c)