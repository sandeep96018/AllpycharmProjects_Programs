#a=10
#b=15
#c=sum((a,b))
"""def function1(a,b):
    print("hello you are in function 1",a+b)
function1(10,22)"""
def function2(a,b):
    """this is function which will calculate average of only two numbers"""
    average=(a+b)/2
    return  average
    #print(average)
v=function2(5,7)
print(v)
print(function2.__doc__)
