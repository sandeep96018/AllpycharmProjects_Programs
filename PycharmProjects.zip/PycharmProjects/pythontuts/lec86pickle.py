import pickle
# #pickling a Python project
# cars=["Audi","BMW","MAruti Sujuki","Ferrari"]
# file="mycar.pkl"
# fileobj=open(file,'wb')
# pickle.dump(cars,fileobj)
# fileobj.close()

file="mycar.pkl"
fileobj=open(file,'rb')
mycar=pickle.load(fileobj)
print(mycar )