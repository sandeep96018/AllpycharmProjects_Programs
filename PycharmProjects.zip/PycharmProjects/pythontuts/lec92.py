a=[6,4,"34"]
# b=[6,4,"34"]
b=a

print(b is a)

#  == value equality
# is  reference equality