# f=open("harry2.txt","a")
# a=f.write("Harry bhai bahut acche hain \n")
# print(a)
# f.close()


#f=open("harry2.txt","a")
# a=f.write("Harry bhai bahut acche hain \n")
# print(a)
# f.close()


#handle read write both
f=open("harry2.txt","r+")
print(f.read())
f.write("thankyou")
f.close()