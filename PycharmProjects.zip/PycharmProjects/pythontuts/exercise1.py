while(True):
    print("enter any number")
    num=int(input())
    if num<100:
        continue
    elif num>=100:
        print("congrates| you have enter above 100 number",num)
        break