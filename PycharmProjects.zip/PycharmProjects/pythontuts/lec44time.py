import time
# initial =time.time()
# print(initial)
# k=0
# while(k<45):
#     print("This is Harry bhai")
#     k+=1
# print("While loop ran in", time.time() - initial,"Seconds")
#
# initial2=time.time()
# print(initial2)
# for i in range(45):
#     print("this is harry bhai")
# print("for loop ran in", time.time() - initial2),"Seconds"

localtime=time.asctime(time.localtime(time.time()))
print(localtime)
