print("if you want to terminate type break")
while(1):

    print("Enter first number")
    n1 = int(input())
    print("Enter second number")
    n2 = int(input())
    print("Please enter Any operator like +,-,*,/,%")
    operater = input()
    # 45*3=555,56+9=77,56/4=4
    if n1 == 45 and n2 == 3 and operater == '*':
        print("555")
    elif n1 == 56 and n2 == 9 and operater == '+':
        print("77")
    elif n1 == 56 and n2 == 4 and operater == '/':
        print("4")
    elif operater == '+':
        addition = n1 + n2
        print(addition)
    elif operater == '-':
        substraction = n1 - n2
        print(substraction)
    elif operater == '*':
        multiplication = n1 * n2
        print(multiplication)
    elif operater == '/':
        devide = n1 / n2
        print(devide)
    elif operater == '%':
        modulas = n1 % n2
        print(modulas)
    else:
        print("Error!please check your input")