import random
# random_number=random.randint(1,6)
# print(random_number)
# rand=random.random()*100
# print(rand)

lst=["Star plus","Aaj tak","Ndtv","Codewithharry","Zee news"]
choice=random.choice(lst)
print(choice)
