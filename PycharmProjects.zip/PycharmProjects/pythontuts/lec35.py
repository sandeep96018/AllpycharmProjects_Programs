# l=10
# def function1(n):
#     #l=5
#     global  l
#     l=l+20
#     m=8
#     print(l)
#     print(n,"i have printed")
# function1("this is me")
# #print(m)
x=33
def harry():
    x=20
    def rohan():
        #global x
        x=88
        print(x,"in rohan function")
    print("before calling rohan()",x)
    rohan()
    print("After calling Rohan()",x)
harry()
print(x)