i=0
while(i<45):
    print(i)
    i=i+1