text = "X-DSPAM-Confidence:    0.8475";
text1=text.find(" ")
l=len(text)
sub=text[text1+1 : l]
print(float(sub))