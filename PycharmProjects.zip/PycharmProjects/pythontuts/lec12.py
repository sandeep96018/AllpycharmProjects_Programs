#dictionary is nothing but key value pairs
#d1=()
#print(type(d1))
d2={"Harry":"Burger","Rohan":"Fish","Skillf":"Roti","Shubham":{"Morning":"Egg","Noon":"roti","evening":"chicken"}}
#print(d2["Shubham"]["Noon"])
#d2["ankit"]="matan"
#d2["rintu"]="aam"
#d2["420"]="ghoda"
#del d2["rintu"]
#print(d2)
#d3=d2
#del d3["Harry"]
#d3=d2.copy()
#del d3["Harry"]
#print(d3)
#print(d2.get("Harry"))
#print(d2.update({"sandeep":"andasss"}))
#print(d2.keys())
print(d2.items())