# def print_name(a,b,c,d):
#     print(a,b,c,d)
# print_name("Sandeep","Shivam","Abhishek","Kuldeep")

def funargs(normal,*args,**kwars):
    print(normal)
    for item in args:
        print(item)
    for key,value in kwars.items():
        print(f"{key} is a {value}")
har=["Sandeep","Shivam","Abhishek","Kuldeep","Rahul"]
normal="i am a normal Argument"
kw={"Sandeep":"Student","Harry":"Teacher","Abhishek":"Partner"}
funargs(normal,*har,**kw)