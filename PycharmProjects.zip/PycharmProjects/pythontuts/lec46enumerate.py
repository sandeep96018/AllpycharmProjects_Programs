lst=["bhindi","egg","alloo","chicken"]
# i=1
# for item in lst:
#     if i%2 is 0:
#         print(f"Please buy item {item}")
#     i += 1

for index,item in enumerate(lst):
    if index%2==0:
        print((f"Please buy these {item}"))