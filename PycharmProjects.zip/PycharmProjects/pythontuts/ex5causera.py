largest = None
smallest = None
while True:
        num = input("Enter a number: ")
        if num == 'done':
            break
        try:
            fnum = float(num)
        except:
            print("Invalid input")
            continue
lst = []
numbers = int(input('How many numbers: '))
for n in range(numbers):

    lst.append(num)
print("Maximum element in the list is :", max(lst), "\nMinimum element in the list is :", min(lst))