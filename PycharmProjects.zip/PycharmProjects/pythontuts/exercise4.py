print("enter any number of rows")
num=int(input())
i=0
print("enter 1 or 0")
c=int(input())
b=bool(c)
if b== True:
    while(i<num):
        j=0
        while(i>=j):
            print("*",end=" ")
            j=j+1
        print("\n")
        i=i+1
elif b==False:
    i=0
    while(num>=0):
        j=0
        while(j<num):
            print("*",end=" ")
            j=j+1
        print("\n")
        num=num-1
        i=i+1