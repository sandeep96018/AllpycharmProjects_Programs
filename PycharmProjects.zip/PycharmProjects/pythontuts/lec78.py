f1=open("harry.txt")
try:
    f=open("harry2.txt")
except Exception as e: #we can add multiple exept code eg.IO.and othrs
    print(e)
else:
    print("This will run only if except is not running")
finally:
    print("Run this kisi bhi keemat per")
    f1.close()
print("Important code")