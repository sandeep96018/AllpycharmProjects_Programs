class Employee:

    _pro=10 #protected
    __pri=8 #private
class Programmer(Employee):
    pass

emp=Employee()
emp1=Programmer()
print(emp._pro)
print(emp._Employee__pri)
