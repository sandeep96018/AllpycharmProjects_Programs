dict={"Mutable":"it can channge","Immutable":"can not change","tree":"plant","veg":"tomato,allo,baigan"}
print(dict)
print("enter any key")
key=input("input key values")
key1=key.capitalize()
print(key1,"means",dict[key1])