# a=input("What is your name?")
# b=input("How much do you earn")
#
# if int(b)==0:
#     raise ZeroDivisionError("B is ZEro so stopping the program")
#
# if a.isnumeric():
#     raise Exception("Numbers Are Not Allowed")
# print(f"Hello {a}")

c=input("Enter Your Name")
try:
    print(a)
except Exception as e:
    if c=="harry":
        raise ValueError("harry is blocked.he is not allowed")
    print("Exception handeled")