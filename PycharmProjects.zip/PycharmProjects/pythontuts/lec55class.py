class Student:
    pass
harry=student()
sandeep=student()

harry.name="HArry"
harry.std=12
harry.sec=1

sandeep.name="Sandeep Kushwaha"
sandeep.std=10
sandeep.sec=5
sandeep.subjects=["Hindi","English","Math"]
print(harry.std,sandeep.subjects)