# import sklearn as sk
# print(sk.__version__)
# import sys
# print(sys.path)
# from sklearn.ensemble import RandomForestClassifier
# print(RandomForestClassifier())
import lec47file2
print(lec47file2.a)
print(lec47file2.printjoke("Hello i am sandeep"))