class Employee:
    number_of_leaves=8
    def __init__(self,aname,asalary,arole):
        self.name=aname
        self.salary=asalary
        self.role=arole

    def printdetails(self):
        return f"Name is {self.name},salary is {self.salary} and role is {self.role}"

    @classmethod
    def change_leaves(cls,newleaves):
        cls.number_of_leaves=newleaves

harry=Employee("Harry",5000,"Instructor")
rohan=Employee("Rohan",10000,"Student")
rohan.change_leaves(34)
print(harry.number_of_leaves)
print(Employee.number_of_leaves)
# print(harry.printdetails())