#Polymorphishm
print(5 + 6)
print("5" + "6")