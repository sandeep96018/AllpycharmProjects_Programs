class Employee:
    number_of_leaves=8
    def __init__(self,aname,asalary,arole):
        self.name=aname
        self.salary=asalary
        self.role=arole

    def printdetails(self):
        return f"Name is {self.name},salary is {self.salary} and role is {self.role}"
harry=Employee("Harry",5000,"Instructor")
rohan=Employee("Rohan",10000,"Student")
#
# harry.name="Harry"
# harry.salary=5000
# harry.role="Instructor"
#
# rohan.name="Rohan"
# rohan.salary=8000
# rohan.role="Student"

print(rohan.printdetails())